/*
훌륭한 인공지능(AI)을 만들고 싶은 마음을 담은 자화상을 집으로 표현하였습니다.
인간의 뇌를 닮은 집과 뉴런에서 에너지가 발화하는 모습을 표현하였습니다.
집이 하늘에 떠있는 모습은 '규격과 틀을 벗어난 창의적 사고'를 뜻합니다.

디지털콘텐츠학과 이동훈
*/


function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(220);
	
	//두뇌를 닮은 집의 좌표 포인트를 미리 잡습니다. x0~x15, y1~y8
	
	x1=150;
	x2=170;
	x3=200;
	x4=220;
	x5=240;
	x6=280;
	x7=310;
	x8=340;
	x9=360;
	x10=380;
	x11=410;
	x12=430;
	x13=460;
	x14=490;
	x15=510;
	
	
	y1=100;
	y2=130;
	y3=140;
	y4=160;
	y5=220;
	y6=250;
	y7=280;
	y8=300;
	
	let c1 = color(120, 120, 120); // Define color 'c'
	fill(c1); // Use color variable 'c' as fill color
	strokeWeight(2);
	stroke(80);
	
	
	//두뇌를 그리는 부분
	triangle(x1, y4, x2, y2, x2, y5);
	triangle(x2, y2, x4, y1, x5, y3);
	triangle(x4, y1, x6, y1, x5, y3);
	triangle(x6, y1, x5, y3, x7, y4);
	triangle(x5, y3, x7, y4, x8, y5);
	triangle(x7, y4, x8, y5, x9, y5);
	triangle(x8, y5, x9, y5, x12, y6);
	triangle(x6, y1, x8, y1, x7, y4);
  triangle(x8, y1, x9, y3, x7, y4);
	triangle(x8, y1, x9, y3, x10, y2);
	triangle(x9, y3, x11, y4, x10, y2);
	triangle(x9, y3, x11, y4, x7, y4);
	triangle(x7, y4, x11, y4, x9, y5);
	triangle(x11,y4, x12, y6, x9, y5);
	triangle(x2, y2, x2, y5, x6, y5);
	triangle(x5, y3, x2, y2, x6, y5);
	triangle(x5, y3, x6, y5, x8, y5);
	triangle(x6, y5, x8, y5, x7, y7);
	triangle(x8, y5, x9, y8, x7, y7);
	triangle(x9, y8, x10, y7, x8, y5);
	triangle(x10, y7, x8, y5, x12, y6);
	triangle(x12, y6, x12, y5, x11, y4);
	triangle(x10, y7, x12, y6, x9, y8);
	triangle(x3, y5, 295, 250, x7, y5);
	
	//문의 좌표
  door_x = 180;
	door_y = 180;
	
	//문을 그립니다.
	let c2 = color(255, 255, 255); // Define color 'c'
	fill(c2); // Use color variable 'c' as fill color
	strokeWeight(2);
	
	rect(door_x,door_y,40,40);
	
	//문 손잡이를 그립니다.
  door_handle_x = 210;
	door_handle_y = 200;
	
	circle(door_handle_x,door_handle_y,2);
	
	
	
	
	
	//두뇌처럼 뉴런이 발화하는 지점을 circle로 표현합니다.
	let c3 = color(255, 255, 255); // Define color 'c'
	fill(c3); // Use color variable 'c' as fill color
	noStroke();
	
	circle(x1,y4,2);
	circle(x2,y2,3);
	circle(x4,y1,3);
	circle(x6,y1,3);
	circle(x5,y3,5);
	circle(x7,y4,7);
	circle(x8,y5,5);
	circle(x9,y5,2);
	
	circle(x12,y6,2);
	circle(x10,y7,3);
	
	
	circle(x8,y1,3);
	circle(x10,y2,4);
	circle(x11,y4,3);
	circle(x12,y5,2);
	
	circle(x2,y5,2);
	circle(x6,y5,4);
	circle(x7,y7,2);
	circle(x9,y3,2);
	circle(x9,y8,4);
	
	//집 주변 빛이 나는 포인트좌표를 그린다.
	lx1=100
	lx2=140
	lx3=170
	lx4=210
	lx5=270
	lx6=310
	lx7=320
	lx8=330
	lx9=410
	lx10=450
	lx11=470
	lx12=510
	lx13=520
	
	ly1=70
	ly2=100
	ly3=120
	ly4=140
	ly5=170
	ly6=220
	ly7=240
	ly8=310
	ly9=350
	ly10=370
	
	
	
	
	circle(lx1,ly4,2);
	circle(lx2,ly2,3);
	circle(lx4,ly1,3);
	circle(lx6,ly1,3);
	circle(lx5,ly3,5);
	circle(lx7,ly4,7);
	circle(lx8,ly5,5);
	circle(lx9,ly5,2);
	
	circle(lx12,ly6,2);
	circle(lx10,ly7,3);
	circle(lx1,ly3,5);
	circle(lx8,ly4,7);
	circle(lx10,ly5,5);
	circle(lx3,ly5,2);
	
	circle(lx7,ly6,2);
	circle(lx3,ly7,3);
	
	circle(lx8,ly1,3);
	circle(lx10,ly2,4);
	circle(lx11,ly4,3);
	circle(lx12,ly5,2);
	
	circle(lx2,ly5,2);
	circle(lx6,ly5,4);
	circle(lx7,ly7,2);
	circle(lx9,ly3,2);
	circle(lx9,ly8,4);
	
	//집의 그림자를 그려준다.
	let c4 = color(100, 100, 100); // Define color 'c'
	fill(c4); // Use color variable 'c' as fill color
	noStroke();
	sx1= 290
	sy1= 350
	s_width = 250
	s_height = 55
	
	ellipse(sx1,sy1,s_width,s_height);
	
	//나무를 그려준다.
	
	tx1=490
	tx2=550
	
	ty1= 360
	ty2= 275
	ty3= 230
	
	t_width = 50
	t_height = 100

	
	strokeWeight(3);
	stroke(70);
	
	line(tx1,ty1,tx1,ty2);
	line(tx2,ty1,tx2,ty2);
	noStroke();
	
	ellipse(tx1,ty3,t_width,t_height);
	ellipse(tx2,ty3,t_width,t_height);
	
	
}